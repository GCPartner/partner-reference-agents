import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pg8000
import sqlalchemy
from google.cloud.sql.connector import Connector, IPTypes
from google.cloud import secretmanager

import os

PROJECT_ID = os.environ.get("PROJECT_ID", "veer-agents-test")
DB_CONN_SECRET = os.environ.get("DB_CONN_SECRET", "phone_plan_db_connection_name")
DB_USER_SECRET = os.environ.get("DB_USER_SECRET", "phone_plan_db_user")
DB_PASS_SECRET = os.environ.get("DB_PASS_SECRET", "phone_plan_db_password")
DB_NAME_SECRET = os.environ.get("DB_NAME_SECRET", "phone_plan_db_name")

_pool = None

def get_secret(secret_id):
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{PROJECT_ID}/secrets/{secret_id}/versions/latest"
    try:
        response = client.access_secret_version(request={"name": name})
        return response.payload.data.decode("UTF-8")
    except Exception as e:
        print(f"Error fetching secret {secret_id}: {e}")
        return None

def get_connection_pool():
    global _pool
    if _pool:
        return _pool

    instance_connection_name = get_secret(DB_CONN_SECRET)
    db_user = get_secret(DB_USER_SECRET)
    db_pass = get_secret(DB_PASS_SECRET)
    db_name = get_secret(DB_NAME_SECRET)

    if not all([instance_connection_name, db_user, db_pass, db_name]):
        raise Exception("Database credentials not found in Secret Manager.")

    connector = Connector()

    def getconn() -> pg8000.dbapi.Connection:
        conn: pg8000.dbapi.Connection = connector.connect(
            instance_connection_name,
            "pg8000",
            user=db_user,
            password=db_pass,
            db=db_name,
            ip_type=IPTypes.PUBLIC,
        )
        return conn

    _pool = sqlalchemy.create_engine(
        "postgresql+pg8000://",
        creator=getconn,
    )
    return _pool

def search_plans(data_limit: Optional[str] = None, intl_calling: Optional[bool] = None, provider: Optional[str] = None) -> List[Dict]:
    """
    Search for available phone plans based on user requirements.
    
    Args:
        data_limit: e.g., "high", "unlimited", "5GB".
        intl_calling: True if the user needs international calling.
        provider: e.g., "AT&T", "T-Mobile".
        
    Returns:
        List of matching plans (dicts).
    """
    pool = get_connection_pool()
    query = "SELECT id, name, provider, data, intl_calling, price FROM plans WHERE 1=1"
    params = {}

    if intl_calling is not None:
        query += " AND intl_calling = :intl_calling"
        params["intl_calling"] = intl_calling
        
    if provider:
        query += " AND LOWER(provider) LIKE LOWER(:provider)"
        params["provider"] = f"%{provider}%"
        
    if data_limit and "unlimited" in data_limit.lower():
        query += " AND data = 'Unlimited'"

    results = []
    with pool.connect() as conn:
        result = conn.execute(sqlalchemy.text(query), params)
        for row in result:
            results.append({
                "id": row[0],
                "name": row[1],
                "provider": row[2],
                "data": row[3],
                "intl_calling": row[4],
                "price": float(row[5])
            })
            
    return results

def search_devices(plan_id: str, model_name: Optional[str] = None, brand: Optional[str] = None) -> List[Dict]:
    """
    Search for mobile devices eligible for the selected plan.
    Higher tier plans unlock more premium devices.

    Args:
        plan_id: The ID or NAME of the plan the user has selected (REQUIRED).
        model_name: specific model to filter by.
        brand: manufacturer to filter by.

    Returns:
        List of available devices for that plan. Note: returns empty if plan_id is invalid.
    """
    # Normalize input to handle LLM sometimes passing the name instead of the ID
    plan_query = plan_id.lower().strip()
    
    # Define Tiers: 1 (Basic), 2 (Mid), 3 (Premium)
    plan_tiers = {
        "p1": 1, "basic saver": 1,
        "p4": 2, "data plus": 2,
        "p2": 3, "standard unlimited": 3,
        "p3": 3, "global traveler": 3
    }
    
    current_tier = plan_tiers.get(plan_query)
    
    # Fuzzy match fallback
    if not current_tier:
        for key, tier in plan_tiers.items():
            if key in plan_query:
                current_tier = tier
                break

    if not current_tier:
        return [{"error": f"Invalid or missing plan_id: {plan_id}. User must select a valid plan first."}]

    pool = get_connection_pool()
    query = "SELECT id, name, brand, storage, price FROM devices WHERE min_tier <= :tier"
    params = {"tier": current_tier}

    if brand:
        query += " AND LOWER(brand) LIKE LOWER(:brand)"
        params["brand"] = f"%{brand}%"
        
    if model_name:
        query += " AND LOWER(name) LIKE LOWER(:model_name)"
        params["model_name"] = f"%{model_name}%"

    results = []
    with pool.connect() as conn:
        result = conn.execute(sqlalchemy.text(query), params)
        for row in result:
            results.append({
                "id": row[0],
                "name": row[1],
                "brand": row[2],
                "storage": row[3],
                "price": float(row[4])
            })
    
    return results

def calculate_total(plan_price: float, device_price: float = 0.0, discount_percent: float = 0.0) -> Dict:
    """
    Calculate the total monthly and upfront cost.

    Args:
        plan_price: Monthly cost of the plan.
        device_price: Upfront cost of the device.
        discount_percent: Any discount to apply (0-100).

    Returns:
        Dict with subtotal, discount_amount, and final_total.
    """
    total = plan_price + device_price
    discount_amount = total * (discount_percent / 100)
    final_total = total - discount_amount
    
    return {
        "monthly_plan_cost_after_discount": round(plan_price * (1 - discount_percent/100), 2),
        "upfront_device_cost_after_discount": round(device_price * (1 - discount_percent/100), 2),
        "total_first_month": round(final_total, 2)
    }

def request_manager_discount(justification: str) -> Dict:
    """
    Request a discretionary discount from a virtual manager.
    
    Args:
        justification: Reason why the customer deserves a discount.
        
    Returns:
        Dict indicating if approved and the discount percentage (e.g. 10 or 15).
    """
    # Simulate manager logic: usually approves 10%, sometimes 15% if justified
    if len(justification) > 10:
        return {"approved": True, "discount_percent": 15.0, "message": "Manager approved 15% discount."}
    return {"approved": True, "discount_percent": 10.0, "message": "Manager approved 10% discount."}

def create_order(plan_id: str, device_id: Optional[str] = None, applied_discount: float = 0.0) -> Dict:
    """
    Finalize the purchase.

    Args:
        plan_id: Selected plan ID (REQUIRED).
        device_id: Selected device ID (optional).
        applied_discount: The discount percentage applied.

    Returns:
        Order confirmation details. Note: If plan_id is missing this will return a failure.
    """
    if not plan_id:
        return {"status": "FAILED", "reason": "A valid plan_id is required to create an order."}

    order_id = f"ORD-{random.randint(1000, 9999)}"
    delivery = (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d")
    
    return {
        "status": "SUCCESS",
        "order_id": order_id,
        "expected_delivery": delivery,
        "message": "Order processed successfully."
    }
