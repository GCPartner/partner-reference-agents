import requests
import json
import time

URL = "http://localhost:8000/jsonrpc"
SESSION_ID = f"session_test_{int(time.time())}"

def send_rpc(text, parts=None):
    payload = {
        "jsonrpc": "2.0",
        "method": "message/send",
        "params": {
            "message": {
                "text": text,
            },
            "session_id": SESSION_ID
        },
        "id": int(time.time() * 1000)
    }
    if parts:
        payload["params"]["message"]["parts"] = parts
        
    print(f"\n---> Sending request: {text}")
    if parts:
        print(f"Parts context: {json.dumps(parts, indent=2)}")
        
    res = requests.post(URL, json=payload)
    print(f"<--- Status code: {res.status_code}")
    res_data = res.json()
    
    # Print text response
    text_out = ""
    a2ui_out = None
    
    if "result" in res_data:
        msg = res_data["result"].get("message", {})
        text_out = msg.get("text", "")
        for part in msg.get("parts", []):
            if part.get("metadata", {}).get("mimeType") == "application/json+a2ui":
                a2ui_out = part.get("data")
    else:
        print(f"Error in response: {res_data}")
        
    print(f"Text Response: {text_out}")
    if a2ui_out:
        print("A2UI Output keys structure:")
        print(json.dumps(a2ui_out, indent=2)[:2000]) # print first 2000 chars of A2UI JSON
    return text_out, a2ui_out

# 1. Start flow by pointing to the CSV file
print("--- Turn 1: Pointing to CSV ---")
text, a2ui = send_rpc("Analyze this performance data spreadsheet: gs://partner-engg-agents-adk-staging/uploaded_files/test_performance.csv")

# Wait 5 seconds to let server cool down
time.sleep(5)

# 2. Confirm the schema (simulating clicking "Confirm Schema" button)
# The schema confirmation action context is:
# action = confirmSchema
# state_col = State
# revenue_col = Revenue
# offering_col = Offering
print("\n--- Turn 2: Confirming Schema ---")
parts = [
    {
        "data": {
            "userAction": {
                "name": "submit",
                "context": {
                    "message": "Confirm Schema",
                    "action": "confirmSchema",
                    "state_col": "State",
                    "revenue_col": "Revenue",
                    "offering_col": "Offering"
                }
            }
        },
        "metadata": {
            "mimeType": "application/json+a2ui"
        }
    }
]
text, a2ui = send_rpc("Confirm Schema", parts=parts)

time.sleep(5)

# 3. Select chart type "bar"
print("\n--- Turn 3: Selecting Bar Chart ---")
parts = [
    {
        "data": {
            "userAction": {
                "name": "submit",
                "context": {
                    "message": "Show the Bar Chart.",
                    "action": "changeChartType",
                    "chart_type": "bar"
                }
            }
        },
        "metadata": {
            "mimeType": "application/json+a2ui"
        }
    }
]
text, a2ui = send_rpc("Show the Bar Chart.", parts=parts)
