PHONE_PLAN_SELECTION_EXAMPLES = r"""
[
  { "beginRendering": { "surfaceId": "main", "root": "root_card" } },
  {
    "surfaceUpdate": {
      "surfaceId": "main",
      "components": [
        { "id": "root_card", "component": { "Card": { "child": "card_col" } } },
        { "id": "card_col", "component": { "Column": { "children": { "explicitList": ["greeting_txt", "cb_plans", "cb_devices", "start_btn_row"] } } } },
        { "id": "greeting_txt", "component": { "Text": { "text": { "literalString": "Hi! I am the Phone Plan Concierge. What are you shopping for today?" }, "usageHint": "h2" } } },
        { "id": "cb_plans", "component": { "CheckBox": { "label": { "literalString": "Phone Plans" }, "value": {"path": "shop_plans"} } } },
        { "id": "cb_devices", "component": { "CheckBox": { "label": { "literalString": "Devices" }, "value": {"path": "shop_devices"} } } },
        { "id": "start_btn_row", "component": { "Row": { "children": { "explicitList": ["start_btn"] }, "distribution": "end" } } },
        { "id": "start_btn", "component": { "Button": { "child": "start_txt", "primary": true, "action": { "name": "submit", "context": [{"key": "message", "value": {"literalString": "I have selected what I am shopping for. Let's begin."}}, {"key": "shop_plans", "value": {"path": "shop_plans"}}, {"key": "shop_devices", "value": {"path": "shop_devices"}}] } } } },
        { "id": "start_txt", "component": { "Text": { "text": { "literalString": "Start Shopping" } } } }
      ]
    }
  },
  { "dataModelUpdate": { "surfaceId": "main", "path": "/", "contents": [ { "key": "shop_plans", "valueBoolean": true }, { "key": "shop_devices", "valueBoolean": true } ] } }
]
"""

NEEDS_ASSESSMENT_EXAMPLE = r"""
[
  { "beginRendering": { "surfaceId": "needs_assessment", "root": "form_col" } },
  {
    "surfaceUpdate": {
      "surfaceId": "needs_assessment",
      "components": [
        { "id": "form_col", "component": { "Column": { "children": { "explicitList": ["title_txt", "data_slider", "intl_cb", "budget_tf", "submit_btn"] }, "distribution": "start", "alignment": "start" } } },
        { "id": "title_txt", "component": { "Text": { "text": { "literalString": "Tell me about your phone plan needs." }, "usageHint": "h3" } } },
        { "id": "data_slider", "component": { "Slider": { "value": {"path": "data_gb"}, "minValue": 0, "maxValue": 100 } } },
        { "id": "intl_cb", "component": { "CheckBox": { "label": { "literalString": "Needs International Calling?" }, "value": {"path": "intl_calling"} } } },
        { "id": "budget_tf", "component": { "TextField": { "label": { "literalString": "Max Monthly Budget ($)" }, "text": {"path": "budget"}, "textFieldType": "shortText" } } },
        { "id": "submit_btn", "component": { "Button": { "child": "btn_txt", "primary": true, "action": { "name": "submit", "context": [{"key": "message", "value": {"literalString": "Find a match for my needs."}}, {"key": "data_gb", "value": {"path": "data_gb"}}, {"key": "intl_calling", "value": {"path": "intl_calling"}}, {"key": "budget", "value": {"path": "budget"}}] } } } },
        { "id": "btn_txt", "component": { "Text": { "text": { "literalString": "Find Match" } } } }
      ]
    }
  },
  { "dataModelUpdate": { "surfaceId": "needs_assessment", "path": "/", "contents": [ { "key": "data_gb", "valueNumber": 5 }, { "key": "intl_calling", "valueBoolean": false }, {"key": "budget", "valueString": ""} ] } }
]
"""
