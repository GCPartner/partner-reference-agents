import os
from pydantic_settings import BaseSettings, SettingsConfigDict

os.environ["PROJECT_ID"] = "123"

class S1(BaseSettings):
    model_config = {"extra": "ignore"}
    host: str = "0.0.0.0"

class S2(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")
    host: str = "0.0.0.0"

print("S1:", S1().model_dump())
print("S2:", S2().model_dump())
