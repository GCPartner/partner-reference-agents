#!/bin/bash

# Configuration
PROJECT_ID="veer-agents-test"
REGION="us-central1"
INSTANCE_NAME="phone-plan-db-$(date +%s)"
DB_NAME="phone_plan_shopper"
DB_USER="phone_plan_app"
DB_PASS=$(openssl rand -base64 12)

echo "Setting project to $PROJECT_ID..."
gcloud config set project $PROJECT_ID

echo "Enabling necessary APIs (Cloud SQL, Secret Manager, Compute Engine)..."
gcloud services enable sqladmin.googleapis.com secretmanager.googleapis.com compute.googleapis.com --project=$PROJECT_ID

echo "Creating Cloud SQL PostgreSQL instance ($INSTANCE_NAME)..."
gcloud sql instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --region=$REGION \
    --database-version=POSTGRES_15 \
    --tier=db-f1-micro \
    --edition=enterprise

echo "Creating database ($DB_NAME)..."
gcloud sql databases create $DB_NAME --instance=$INSTANCE_NAME --project=$PROJECT_ID

echo "Creating database user ($DB_USER)..."
gcloud sql users create $DB_USER --instance=$INSTANCE_NAME --password=$DB_PASS --project=$PROJECT_ID

# Get connection name
CONNECTION_NAME=$(gcloud sql instances describe $INSTANCE_NAME --project=$PROJECT_ID --format="value(connectionName)")

echo "Creating secrets in Secret Manager..."

# Helper function to create/update secret
create_secret() {
    SECRET_NAME=$1
    SECRET_VALUE=$2
    
    if gcloud secrets describe $SECRET_NAME --project=$PROJECT_ID >/dev/null 2>&1; then
        echo "Updating existing secret: $SECRET_NAME"
        echo -n "$SECRET_VALUE" | gcloud secrets versions add $SECRET_NAME --data-file=- --project=$PROJECT_ID
    else
        echo "Creating new secret: $SECRET_NAME"
        echo -n "$SECRET_VALUE" | gcloud secrets create $SECRET_NAME --data-file=- --replication-policy="automatic" --project=$PROJECT_ID
    fi
}

create_secret "phone_plan_db_connection_name" "$CONNECTION_NAME"
create_secret "phone_plan_db_user" "$DB_USER"
create_secret "phone_plan_db_password" "$DB_PASS"
create_secret "phone_plan_db_name" "$DB_NAME"

echo "==========================================================="
echo "Cloud SQL Provisioning Complete!"
echo "Instance: $INSTANCE_NAME"
echo "Database: $DB_NAME"
echo "User: $DB_USER"
echo "Connection Name: $CONNECTION_NAME"
echo ""
echo "Secrets have been stored in Google Cloud Secret Manager:"
echo "- phone_plan_db_connection_name"
echo "- phone_plan_db_user"
echo "- phone_plan_db_password"
echo "- phone_plan_db_name"
echo "==========================================================="
