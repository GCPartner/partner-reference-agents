# Phone Plan Shopper - Testing Guide

This document outlines several scenarios you can use to test the `PhonePlanConcierge` agent interactively using the `adk web` interface. 

To start testing, run:
```bash
adk web
```
Then select **PhonePlanConcierge** from the agent dropdown.

---

## 📱 Scenario 1: The "Happy Path" (Flow Enforcement)
*Tests that the agent correctly forces you to pick a plan before exploring devices.*

**You say:**
> "I want the new Pixel 9 Pro."

**Expected Behavior:**
The agent should politely explain that devices are dependent on the plan you choose. It will ask you about your data needs to recommend a plan FIRST.

**You follow up:**
> "Oh okay, I need an unlimited plan with international calling."

**Expected Behavior:**
The agent recommends the "Global Traveler" plan (Tier 3). It will then use your `plan_id` to search for eligible devices and confirm that the Pixel 9 Pro is available for this premium plan.

---

## 🛑 Scenario 2: Tier Restriction Check
*Tests the new logic where Basic (Tier 1) plans cannot access Premium (Tier 3) devices.*

**You say:**
> "I want the cheapest basic plan you have."

**Expected Behavior:**
The agent should recommend the "Basic Saver" plan ($30).

**You follow up:**
> "Great, I'll take that. What phones can I get? Can I get the Pixel 9 Pro?"

**Expected Behavior:**
The agent should check the devices for the Basic Saver plan. It MUST NOT offer the Pixel 9 Pro (Tier 3). It should only offer Tier 1 devices like the iPhone 14 or Galaxy A54, and explain that the Pixel 9 Pro requires a higher-tier plan.

---

## 🤝 Scenario 2: The "Deal Hunter" (Negotiation)
*Tests the agent's discount logic and state retention over a longer conversation.*

**You say:**
> "What's the best unlimited plan you have with international calling? I also want a Pixel 9 Pro."

**Expected Behavior:**
The agent should recommend the "Global Traveler" plan (AT&T) and the Pixel 9 Pro. It will ask if you want to proceed.

**You follow up:**
> "That total is a bit high. Can I get a manager discount? I've been a loyal employee for 10 years."

**Expected Behavior:**
The agent will use the `request_manager_discount` tool. It will proudly announce a 15% discount and recalculate your new total, keeping the same device and plan in its 'cart'.

**You conclude:**
> "That's great! Order it."

---

## 🎒 Scenario 3: BYOD (Bring Your Own Device)
*Tests if the agent can skip the device search gracefully when only a plan is needed.*

**You say:**
> "I already have an iPhone. I just need a basic saver plan."

**Expected Behavior:**
The agent should skip searching for devices altogether, recommend the $30 Basic Saver plan, and ask if you want to place the order for just the plan.

---

## 🤔 Scenario 4: Ambiguous Requirements
*Tests the agent's ability to act as a concierge and narrow down options.*

**You say:**
> "I need a new Samsung phone."

**Expected Behavior:**
The agent should list the available Samsung device(s) (e.g., Galaxy S24) and ask what kind of phone plan you would like to pair it with (asking about data needs).

---

## 🚫 Scenario 5: Out of Stock / Unavailable
*Tests the agent's error handling and helpfulness when tools return empty results.*

**You say:**
> "I really want a Gold iPhone 4."

**Expected Behavior:**
The agent should smoothly handle the fact that the iPhone 4 is not in the mock database. It should apologize, politely inform you that it's unavailable, and suggest newer iPhone models (like the iPhone 14 or 15) instead.
