import math
import json

COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#06b6d4", "#84cc16"]

def get_html_template(chart_data: dict, chart_type: str) -> str:
    """Returns a self-contained HTML page representing a pure CSS/SVG visualizer (no CDNs)."""
    
    # 1. Pie/Doughnut Chart
    if chart_type == "pie":
        labels = chart_data.get("labels", [])
        dataset = chart_data.get("datasets", [{}])[0]
        data = dataset.get("data", [])
        bg_colors = dataset.get("backgroundColor", COLORS)
        
        total = sum(data)
        if total == 0:
            return "<div>No data to display.</div>"
            
        cx, cy, r = 100, 100, 80
        paths = []
        current_angle = -math.pi / 2  # start at 12 o'clock
        
        for i, (label, val) in enumerate(zip(labels, data)):
            percentage = val / total
            angle_delta = percentage * 2 * math.pi
            end_angle = current_angle + angle_delta
            
            # Start and End points for outer arc
            x1 = cx + r * math.cos(current_angle)
            y1 = cy + r * math.sin(current_angle)
            x2 = cx + r * math.cos(end_angle)
            y2 = cy + r * math.sin(end_angle)
            
            large_arc = 1 if percentage > 0.5 else 0
            
            # Draw standard slice path
            path_d = f"M {cx} {cy} L {x1:.2f} {y1:.2f} A {r} {r} 0 {large_arc} 1 {x2:.2f} {y2:.2f} Z"
            color = bg_colors[i % len(bg_colors)]
            
            click_attr = f"onclick=\"handleSliceClick('{label}')\"" if label != "Other" else ""
            
            paths.append(f"""
            <path d="{path_d}" fill="{color}" class="pie-slice" {click_attr}>
              <title>{label}: ${val:,.2f} ({percentage*100:.1f}%)</title>
            </path>
            """)
            current_angle = end_angle
            
        svg_content = "\n".join(paths)
        
        # Legend items HTML
        legend_items = []
        for i, (label, val) in enumerate(zip(labels, data)):
            color = bg_colors[i % len(bg_colors)]
            legend_items.append(f"""
            <div class="legend-item" onclick="handleSliceClick('{label}')">
              <span class="legend-color-box" style="background-color: {color};"></span>
              <span class="legend-text">{label} (${val:,.2f})</span>
            </div>
            """)
        legend_html = "\n".join(legend_items)
        
        return f"""<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Security-Policy" content="connect-src 'none'">
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 15px;
      background-color: #ffffff;
      overflow: hidden;
    }}
    .chart-layout {{
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: 30px;
      height: 360px;
    }}
    .svg-area {{
      width: 220px;
      height: 220px;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    svg {{
      width: 100%;
      height: 100%;
      filter: drop-shadow(0px 4px 6px rgba(0,0,0,0.06));
    }}
    .pie-slice {{
      cursor: pointer;
      transition: opacity 0.2s ease, transform 0.2s ease;
      transform-origin: 100px 100px;
    }}
    .pie-slice:hover {{
      opacity: 0.85;
      transform: scale(1.03);
    }}
    .legend-area {{
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-width: 280px;
      font-size: 14px;
    }}
    .legend-item {{
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 4px;
      transition: background 0.15s ease;
    }}
    .legend-item:hover {{
      background: #f3f4f6;
    }}
    .legend-color-box {{
      width: 12px;
      height: 12px;
      border-radius: 3px;
      flex-shrink: 0;
    }}
    .legend-text {{
      color: #374151;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
  </style>
</head>
<body>
  <div class="chart-layout">
    <div class="svg-area">
      <svg viewBox="0 0 200 200">
        {svg_content}
      </svg>
    </div>
    <div class="legend-area">
      {legend_html}
    </div>
  </div>
  <script>
    function handleSliceClick(label) {{
      if (label === 'Other') return;
      window.parent.postMessage({{
        type: 'a2ui_action',
        action: 'drillDown',
        data: {{
          message: 'Show performance breakdown by service offerings in ' + label,
          action: 'drillDown',
          state: label
        }}
      }}, '*');
    }}
  </script>
</body>
</html>
"""

    # 2 & 3. Standard and Grouped Bar Charts
    else:
        labels = chart_data.get("labels", [])
        datasets = chart_data.get("datasets", [])
        
        # Calculate scales
        all_values = []
        for ds in datasets:
            all_values.extend(ds.get("data", []))
        
        max_val = max(all_values) if all_values else 1.0
        # Round up to clean power of 10 or nice multiple
        y_max = max_val * 1.15
        
        # SVG Viewbox: 600 x 320
        svg_w, svg_h = 600, 320
        margin_l, margin_r, margin_t, margin_b = 70, 30, 40, 50
        graph_w = svg_w - margin_l - margin_r
        graph_h = svg_h - margin_t - margin_b
        
        svg_bars = []
        svg_labels = []
        svg_grid = []
        
        # Draw Y-Axis labels and grid lines
        grid_ticks = 4
        for step in range(grid_ticks + 1):
            ratio = step / grid_ticks
            val_label = ratio * max_val
            y_pos = margin_t + graph_h - (ratio * graph_h)
            
            # Grid Line
            svg_grid.append(f'<line x1="{margin_l}" y1="{y_pos}" x2="{margin_l + graph_w}" y2="{y_pos}" stroke="#e5e7eb" stroke-dasharray="4 4" />')
            
            # Y label
            if val_label >= 1_000_000:
                label_str = f"${val_label/1_000_000:.1f}M"
            elif val_label >= 1_000:
                label_str = f"${val_label/1_000:.0f}K"
            else:
                label_str = f"${val_label:.0f}"
            
            svg_grid.append(f'<text x="{margin_l - 10}" y="{y_pos + 4}" text-anchor="end" font-size="11" fill="#6b7280">{label_str}</text>')
            
        num_groups = len(labels)
        num_datasets = len(datasets)
        
        group_width = graph_w / max(num_groups, 1)
        
        # Build Legend for Grouped Bar
        legend_html = ""
        if num_datasets > 1:
            legend_items = []
            for i, ds in enumerate(datasets):
                color = ds.get("backgroundColor", COLORS[i % len(COLORS)])
                legend_items.append(f"""
                <div class="legend-item-inline">
                  <span class="legend-color-box" style="background-color: {color};"></span>
                  <span>{ds.get("label", "")}</span>
                </div>
                """)
            legend_html = f'<div class="legend-inline">{"".join(legend_items)}</div>'
            
        # Draw Bars
        for g_idx, group_label in enumerate(labels):
            group_x = margin_l + g_idx * group_width
            
            # X Axis Label
            x_label_center = group_x + group_width / 2
            
            # Handle rotating labels if there are many to avoid collision
            rotate_attr = 'transform="rotate(-20, {}, {})"'.format(x_label_center, margin_t + graph_h + 18) if len(labels) > 6 else ''
            
            svg_labels.append(f"""
            <text x="{x_label_center}" y="{margin_t + graph_h + 18}" text-anchor="middle" font-size="12" font-weight="500" fill="#374151" {rotate_attr}>
              {group_label}
            </text>
            """)
            
            # Calculate dynamic bar width
            total_bars_padding = group_width * 0.25
            available_bar_space = group_width - total_bars_padding
            bar_width = available_bar_space / num_datasets
            
            for d_idx, ds in enumerate(datasets):
                val_list = ds.get("data", [])
                val = val_list[g_idx] if g_idx < len(val_list) else 0.0
                
                bar_h = (val / y_max) * graph_h if y_max > 0 else 0
                bar_x = group_x + (total_bars_padding / 2) + d_idx * bar_width
                bar_y = margin_t + graph_h - bar_h
                
                color = ds.get("backgroundColor", COLORS[d_idx % len(COLORS)])
                
                # Setup click interactions for standard bar charts
                click_attr = ""
                # Only support drillDown if standard bar chart (not breakdown) and label is not "Other"
                if num_datasets == 1 and group_label != "Other":
                    click_attr = f"onclick=\"handleBarClick('{group_label}')\""
                    
                # Rectangle SVG bar with rounded top corners
                svg_bars.append(f"""
                <g class="bar-group" {click_attr}>
                  <rect x="{bar_x:.2f}" y="{bar_y:.2f}" width="{bar_width-2:.2f}" height="{bar_h:.2f}" fill="{color}" rx="3" class="bar">
                    <title>{ds.get("label", "Revenue")}: ${val:,.2f}</title>
                  </rect>
                </g>
                """)
                
        svg_content = "\n".join(svg_grid) + "\n" + "\n".join(svg_bars) + "\n" + "\n".join(svg_labels)
        
        return f"""<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Security-Policy" content="connect-src 'none'">
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 10px 15px;
      background-color: #ffffff;
      overflow: hidden;
    }}
    .chart-container {{
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 380px;
    }}
    .svg-area {{
      width: 100%;
      height: 320px;
    }}
    svg {{
      width: 100%;
      height: 100%;
    }}
    .bar {{
      cursor: pointer;
      transition: fill 0.2s ease, opacity 0.2s ease;
    }}
    .bar:hover {{
      opacity: 0.85;
      filter: brightness(0.95);
    }}
    .legend-inline {{
      display: flex;
      flex-direction: row;
      justify-content: center;
      gap: 15px;
      margin-bottom: 8px;
      font-size: 13px;
      color: #4b5563;
      flex-wrap: wrap;
    }}
    .legend-item-inline {{
      display: flex;
      align-items: center;
      gap: 6px;
    }}
    .legend-color-box {{
      width: 11px;
      height: 11px;
      border-radius: 2px;
      flex-shrink: 0;
    }}
  </style>
</head>
<body>
  <div class="chart-container">
    {legend_html}
    <div class="svg-area">
      <svg viewBox="0 0 {svg_w} {svg_h}" preserveAspectRatio="xMidYMid meet">
        <!-- Axes -->
        <line x1="{margin_l}" y1="{margin_t}" x2="{margin_l}" y2="{margin_t + graph_h}" stroke="#d1d5db" stroke-width="1.5" />
        <line x1="{margin_l}" y1="{margin_t + graph_h}" x2="{margin_l + graph_w}" y2="{margin_t + graph_h}" stroke="#d1d5db" stroke-width="1.5" />
        {svg_content}
      </svg>
    </div>
  </div>
  <script>
    function handleBarClick(label) {{
      window.parent.postMessage({{
        type: 'a2ui_action',
        action: 'drillDown',
        data: {{
          message: 'Show performance breakdown by service offerings in ' + label,
          action: 'drillDown',
          state: label
        }}
      }}, '*');
    }}
  </script>
</body>
</html>
"""

# Let's run a test with simple inputs and print the output
if __name__ == '__main__':
    pie_data = {
        "labels": ["CA", "TX", "NY", "FL", "Other"],
        "datasets": [{
            "data": [1200000.0, 950000.0, 800000.0, 600000.0, 450000.0],
            "backgroundColor": COLORS
        }]
    }
    print("--- PIE CHART SVG SAMPLE ---")
    print(get_html_template(pie_data, "pie")[:500] + "\n...")
    
    bar_data = {
        "labels": ["Consulting", "Software", "Hardware", "Support"],
        "datasets": [{
            "label": "Revenue (USD)",
            "data": [450000.0, 800000.0, 300000.0, 150000.0],
            "backgroundColor": COLORS[0]
        }]
    }
    print("\n--- BAR CHART SVG SAMPLE ---")
    print(get_html_template(bar_data, "bar")[:500] + "\n...")
