import os
import vertexai
from vertexai.preview.reasoning_engines import A2aAgent
from vertexai.preview.reasoning_engines.templates.a2a import create_agent_card
from a2a.types import AgentSkill
from dotenv import load_dotenv
from google.genai import types

import agent_executor

def deploy():
    load_dotenv()
    
    project_id = os.environ.get("PROJECT_ID") or os.environ.get("GOOGLE_CLOUD_PROJECT")
    location = os.environ.get("LOCATION") or os.environ.get("GOOGLE_CLOUD_LOCATION") or "us-central1"
    storage = os.environ.get("STORAGE_BUCKET") or "gs://your-staging-bucket"
    
    print(f"Initializing Vertex AI (Project: {project_id}, Location: {location}, Bucket: {storage})")
    vertexai.init(
        project=project_id,
        location=location,
        staging_bucket=storage,
    )

    # 1. Define Skills & Agent Card
    agent_skill = AgentSkill(
        id="company_performance_analyzer",
        name="Company Performance Analyzer",
        description="An expert assistant for parsing and dynamically charting annual company performance spreadsheet data using A2UI.",
        tags=["Performance-Analysis", "Charts", "A2UI"],
        examples=[
            "Analyze this company performance data.",
            "Show me a pie chart for the top 5 states.",
        ],
    )

    analyzer_card = create_agent_card(
        agent_name="Company Performance Analyzer Agent",
        description="An expert assistant for parsing and dynamically charting annual company performance spreadsheet data using A2UI.",
        skills=[agent_skill],
    )
    
    import json
    print(f"JSON_AGENT_CARD_START{json.dumps(analyzer_card, default=lambda o: o.__dict__)}JSON_AGENT_CARD_END")
    print("✓ Agent card created.")
    
    # 2. Instantiate local A2aAgent
    a2a_agent = A2aAgent(
        agent_card=analyzer_card,
        agent_executor_builder=agent_executor.AdkAgentToA2AExecutor,
    )
    print("✓ Local A2aAgent created.")

    client = vertexai.Client(
        project=project_id,
        location=location,
        http_options=types.HttpOptions(
            api_version="v1beta1",
        ),
    )
    print("✓ Vertex AI client created.")

    # 3. Deploy configuration
    config = {
        "display_name": "Company Performance Analyzer",
        "description": "Analyzes company annual performance spreadsheets and renders interactive Chart.js visualizations.",
        "agent_framework": "google-adk",
        "staging_bucket": storage,
        "requirements": [
            "google-adk==1.28.1",
            "google-cloud-aiplatform[agent_engines,adk]==1.143.0",
            "a2a-sdk==0.3.22",
            "pydantic==2.12.5",
            "cloudpickle==3.1.2",
            "protobuf==6.33.6",
            "jsonschema==4.26.0",
            "a2ui-agent-sdk @ git+https://github.com/google/A2UI.git#subdirectory=agent_sdks/python",
            "pandas",
            "jinja2"
        ],
        "http_options": {
            "api_version": "v1beta1",
        },
        "max_instances": 1,
        "extra_packages": [
            "agent_executor.py",
            "a2ui_schema.py",
            "agent.py",
            "tools.py"
        ],
        "env_vars": {
            "NUM_WORKERS": "1",
        },
    }

    # Prompt user for execution details when running or let them execute it
    print("Staging config prepared:")
    print(json.dumps(config, indent=2))
    
    # Run creation
    print("Deploying new Agent Engine instance...")
    remote_agent = client.agent_engines.create(agent=a2a_agent, config=config)
    print(f"✓ Agent Engine deployed successfully! Resource name: {remote_agent.api_resource.name}")

if __name__ == "__main__":
    deploy()
