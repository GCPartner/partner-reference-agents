import os
import sys
# Ensure sibling modules (tools, a2ui_tools, a2ui_examples) can be found in deployed environments
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import json
from google.adk.agents import LlmAgent
import tools as platform_tools
import a2ui_tools
import a2ui_examples

from a2ui.core.schema.manager import A2uiSchemaManager
from a2ui.core.schema.constants import VERSION_0_8
from a2ui.basic_catalog.provider import BasicCatalog

def get_instructions() -> str:
    """Constructs the full prompt for the agent using standard A2UI utilities."""
    
    role_description = """
    You are the PhonePlanConcierge, an expert corporate benefits assistant.
    Your goal is to help employees find the best phone plans and devices, negotiate discounts if applicable, and place orders.
    """

    ui_description = """
    **TASK FLOW:**
    You have standard scenarios based on user input:

    **Scenario 1: User says Hi or launches the concierge without specific requests.**
    *Action:*
    1. Do NOT ask about data Needs Assessment yet. You must know what they are shopping for first.
    2. Call the `render_ui` tool immediately with a payload rendering the Greeting Card with Checkboxes for 'Phone Plans' and 'Devices'.
    
    **Scenario 2: User says they want to shop for Phone Plans.**
    *Action:*
    1. Call the `render_ui` tool immediately with the Needs Assessment card.
    
    **Scenario 3: User provides their data and calling requirements.**
    *Action:*
    1. Call the `search_plans` tool.
    2. Call the `render_ui` tool if you are presenting options.
    
    **Scenario 4: User is ready to order.**
    *Action:*
    1. Display a Confirmation Card.
    
    **Scenario 5: Discounts (Hidden Feature).**
    *Action:*
    1. Only show 'Request Discount' if user complains about price.
    """

    # Initialize Schema Manager with Basic Catalog
    catalogs = [BasicCatalog.get_config(version=VERSION_0_8)]
    schema_manager = A2uiSchemaManager(version=VERSION_0_8, catalogs=catalogs)
    
    base_prompt = schema_manager.generate_system_prompt(
        role_description=role_description,
        ui_description=ui_description,
        include_schema=False, # Hide schema to force the model to use the render_ui tool
        include_examples=False, # We appending our own
    )

    phone_plan_selection_example = a2ui_examples.PHONE_PLAN_SELECTION_EXAMPLES
    needs_assessment_example = a2ui_examples.NEEDS_ASSESSMENT_EXAMPLE

    return f"""
{base_prompt}

## Additional Rules

When you determine that the user needs a UI (a form, a list, a card), you MUST invoke the `render_ui` tool and pass the A2UI JSON payload as a string to the `a2ui_json` parameter.

**IMPORTANT: never output raw JSON. Always pack it into the `render_ui` tool.**

**CRITICAL: If the `render_ui` tool returns an error (validation or syntax), YOU MUST read the error carefully, fix your JSON, and call the tool again! Do not report the raw error to the user!**

**Tips for Syntax Success:**
- Pay close attention to brace counting. A standard component in the list usually opens 3 braces (Root, 'component' key, ComponentName key) and closes exactly 3 braces (no more, no less). No trailing commas inside the list unless it's between items.

---BEGIN PHONE_PLAN_SELECTION_EXAMPLE---
{phone_plan_selection_example}
---END PHONE_PLAN_SELECTION_EXAMPLE---

---BEGIN NEEDS_ASSESSMENT_EXAMPLE---
{needs_assessment_example}
---END NEEDS_ASSESSMENT_EXAMPLE---
"""


root_agent = LlmAgent(
    name="PhonePlanConcierge",
    description="A helpful corporate benefits assistant for shopping phone plans and devices.",
    model="gemini-2.5-flash",
    instruction=get_instructions(),
    tools=[
        platform_tools.search_plans, 
        platform_tools.search_devices, 
        platform_tools.calculate_total, 
        platform_tools.request_manager_discount, 
        platform_tools.create_order,
        a2ui_tools.render_ui
    ]
)
