import os
import pg8000
import sqlalchemy
from google.cloud.sql.connector import Connector, IPTypes
from google.cloud import secretmanager

# Project ID
PROJECT_ID = "veer-agents-test"

def get_secret(secret_id):
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{PROJECT_ID}/secrets/{secret_id}/versions/latest"
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")

def connect_with_connector() -> sqlalchemy.engine.base.Engine:
    """
    Initializes a connection pool for a Cloud SQL instance of Postgres.
    """
    instance_connection_name = get_secret("phone_plan_db_connection_name")
    db_user = get_secret("phone_plan_db_user")
    db_pass = get_secret("phone_plan_db_password")
    db_name = get_secret("phone_plan_db_name")

    connector = Connector()

    def getconn() -> pg8000.dbapi.Connection:
        conn: pg8000.dbapi.Connection = connector.connect(
            instance_connection_name,
            "pg8000",
            user=db_user,
            password=db_pass,
            db=db_name,
            ip_type=IPTypes.PUBLIC,
        )
        return conn

    pool = sqlalchemy.create_engine(
        "postgresql+pg8000://",
        creator=getconn,
    )
    return pool

def init_db():
    print("Connecting to database...")
    engine = connect_with_connector()

    with engine.connect() as conn:
        print("Creating tables...")
        # Create plans table
        conn.execute(sqlalchemy.text("""
            CREATE TABLE IF NOT EXISTS plans (
                id VARCHAR(255) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                provider VARCHAR(255) NOT NULL,
                data VARCHAR(255) NOT NULL,
                intl_calling BOOLEAN NOT NULL,
                price FLOAT NOT NULL
            );
        """))

        # Create devices table
        conn.execute(sqlalchemy.text("""
            CREATE TABLE IF NOT EXISTS devices (
                id VARCHAR(255) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                brand VARCHAR(255) NOT NULL,
                storage VARCHAR(255) NOT NULL,
                price FLOAT NOT NULL,
                min_tier INTEGER NOT NULL
            );
        """))

        # Clear existing data just in case
        conn.execute(sqlalchemy.text("DELETE FROM plans;"))
        conn.execute(sqlalchemy.text("DELETE FROM devices;"))

        print("Inserting mock data...")
        # Insert plans
        plans_data = [
            ("p1", "Basic Saver", "T-Mobile", "5GB", False, 30.00),
            ("p4", "Data Plus", "Verizon", "15GB", False, 45.00),
            ("p2", "Standard Unlimited", "Verizon", "Unlimited", False, 50.00),
            ("p3", "Global Traveler", "AT&T", "Unlimited", True, 75.00),
        ]
        conn.execute(
            sqlalchemy.text("""
                INSERT INTO plans (id, name, provider, data, intl_calling, price) 
                VALUES (:id, :name, :provider, :data, :intl_calling, :price)
            """),
            [{"id": p[0], "name": p[1], "provider": p[2], "data": p[3], "intl_calling": p[4], "price": p[5]} for p in plans_data]
        )

        # Insert devices
        devices_data = [
            ("d1", "Google Pixel 9", "Google", "128GB", 799.00, 2),
            ("d2", "Google Pixel 9 Pro", "Google", "256GB", 999.00, 3),
            ("d3", "Apple iPhone 15", "Apple", "128GB", 799.00, 2),
            ("d4", "Apple iPhone 14", "Apple", "128GB", 699.00, 1),
            ("d5", "Samsung Galaxy S24", "Samsung", "256GB", 850.00, 3),
            ("d6", "Samsung Galaxy A54", "Samsung", "128GB", 450.00, 1),
        ]
        conn.execute(
            sqlalchemy.text("""
                INSERT INTO devices (id, name, brand, storage, price, min_tier) 
                VALUES (:id, :name, :brand, :storage, :price, :min_tier)
            """),
            [{"id": d[0], "name": d[1], "brand": d[2], "storage": d[3], "price": d[4], "min_tier": d[5]} for d in devices_data]
        )
        
        conn.commit()
    print("Database initialization complete.")

if __name__ == "__main__":
    init_db()
