import json
import os
import jsonschema
from typing import List, Dict, Any
from google.adk.tools.tool_context import ToolContext

from vertexai.preview.generative_models import Part

def render_ui(a2ui_json: str, tool_context: ToolContext = None):
    """Submits the A2UI JSON payload to the client screen to dynamically render user interfaces like forms, cards, and lists.
    
    CRITICAL INSTRUCTIONS FOR LLM:
    - You MUST call this tool INSTEAD of printing raw JSON codeblocks into the chat stream.
    - Pass the entire A2UI JSON payload as a string to the `a2ui_json` parameter.
    - The JSON payload must exactly adhere to the official A2UI Schema v0.8.
    - If you receive a JSON validation error back from this tool, YOU MUST fix your schema based on the error and call the tool again!
    - Example form components: Slider, CheckBox, TextField, Button. DO NOT make up component names.
    
    Args:
        a2ui_json: A valid JSON string containing the A2UI messages array.
            Format: '[{"beginRendering": {"surfaceId": "main", "root": "x"}}, {"surfaceUpdate": {"surfaceId": "main", "components": [...]}}]'
    Returns:
        A binary Part object containing the UI payload for native rendering.
    """
    schema_path = os.path.join(os.path.dirname(__file__), 'a2ui_schema.json')
    try:
        a2ui_messages = json.loads(a2ui_json)
        with open(schema_path, 'r') as f:
            a2ui_schema = json.load(f)
            
        for i, msg in enumerate(a2ui_messages):
            jsonschema.validate(instance=msg, schema=a2ui_schema)
            
        # Return as binary Part
        # Option D: Native Vertex AI Part
        return Part.from_data(data=a2ui_json.encode('utf-8'), mime_type="application/json+a2ui")
        
    except json.JSONDecodeError as e:
        return f"CRITICAL SYNTAX ERROR in your JSON string:\nError: {e.msg}\nLocation: line {e.lineno}, col {e.colno}\nRemedy: Check for extra/missing braces, commas, or quotes near the error location, fix the JSON, and call `render_ui` again!"

    except jsonschema.exceptions.ValidationError as e:
        # Give LLM a path to debug the hallucination.
        path_str = ' -> '.join(str(p) for p in e.path) if e.path else 'Root Level'
        return f"CRITICAL VALIDATION ERROR in your a2ui_messages at message index {i}:\nError: {e.message}\nPath: {path_str}\nRemedy: The component you specified might not match the schema (e.g., using 'RadioGroup' instead of supported schema types, or missing required fields). Read the error carefully, fix the JSON structure, and call `render_ui` again!"
        
    except Exception as e:
        return f"System Error processing A2UI payload: {str(e)}"
