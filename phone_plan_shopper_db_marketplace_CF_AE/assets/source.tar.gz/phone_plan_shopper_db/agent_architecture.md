# Phone Plan Shopper Design Document

## 1. Requirements Analysis
> **Goal**: Enable employees to shop for phone plans and devices with EPP (Employee Purchase Program) discounts via a conversational AI agent.

*   **User Problem**: Employees find it difficult to navigate multiple provider options, understand plan details (data/roaming), and apply eligible EPP discounts manually.
*   **Target Outcome**: An employee can discover plans, select a device, negotiate extra discounts (if applicable), and place a confirmed order through a natural conversation.
*   **Key Constraints**:
    *   **Cost**: Must prioritize "EPP pricing" and "additional discounts".
    *   **Latency**: Interactive chat response < 3s; Tool calls (search/order) < 5s.
    *   **Compliance**: Must only show plans the employee is eligible for (EPP context).
*   **Assumptions**:
    *   User is authenticated; `employee_id` is available in context.
    *   Unified `Adapter` tools exist to aggregate data from multiple telecom providers.

---

## 2. Architecture Design
> **Goal**: Define the structure (Single Agent with Unified Tools).

### 2.1 High-Level Strategy
*   **Pattern**: **Single Agent** (`LlmAgent`)
*   **Rationale**: The workflow is a coherent, linear conversation (Requirements -> Options -> Selection -> Checkout). A single agent with a rich context window can maintain the state of the "Shopping Cart" and "Negotiation Status" without the complexity of multi-agent handoffs.

### 2.2 System Diagram (Logical)
```mermaid
graph TD
    User([Employee]) --> Input[Chat Request]
    Input --> A[PhonePlanConcierge]
    
    subgraph Tools
        A -->|Search| T1[Plan & Device Search]
        A -->|Negotiate| T2[Discount Manager]
        A -->|Checkout| T3[Order System]
    end
    
    T1 -->|Options| A
    T2 -->|Approved/Denied| A
    T3 -->|Order ID| A
    A -->|Confirmation| User
```

### 2.3 Components
#### **A. Agents**
| Name | Type | Model | Role/Persona |
| :--- | :--- | :--- | :--- |
| `PhonePlanConcierge` | `LlmAgent` | `gemini-2.5-flash` | A helpful, knowledgeable corporate benefits assistant. Honest about prices, proactive in finding discounts, and clear about plan limitations. |

#### **B. State Schema (`session.state`)**
| Key | Type | Description | Persistence |
| :--- | :--- | :--- | :--- |
| `employee_id` | `str` | Application-supplied ID for EPP eligibility | Session (Read-Only) |
| `cart` | `dict` | Selected `plan_id`, `device_id`, `addon_ids` | Session |
| `current_offer` | `dict` | Details of the actively discussed quote (price, terms) | Ephemeral |
| `negotiation_status` | `str` | `NONE`, `REQUESTED`, `APPLIED`, `DENIED` | Session |

#### **C. Tools**
| Tool Function | Description | Dependencies |
| :--- | :--- | :--- |
| `search_plans` | Find plans by `data_limit`, `intl_calling`, `provider` | Provider API Adapter |
| `search_devices` | Find devices eligible for a specific `plan_id`. Higher tier plans access lower tier devices. | Provider API Adapter |
| `request_manager_discount` | Request ad-hoc discount. Returns outcome & new price. | Discount Rule Engine |
| `calculate_total` | Get final price breakdown (Plan + Device - Discount). | Pricing Engine |
| `create_order` | Commit the cart to an order. Returns `order_id` & `delivery_date`. | Order Management System |

### 2.4 Execution Flow (Sequence)
> **Goal**: Visualize the Shopping -> Negotiation -> Ordering flow.

```mermaid
sequenceDiagram
    participant U as Employee
    participant A as PhonePlanConcierge
    participant P as ProviderAPI
    participant D as DiscountEngine

    U->>A: "I need a plan with lots of data and a Pixel 9"
    activate A
    A->>A: Parse requirements (Data=High, Device=Pixel 9)
    
    A->>P: search_plans(data="high")
    
    P-->>A: [Plan A, Plan B]
    A-->>U: "Here are 2 great options. Plan A is cheaper..."

    U->>A: "I'll take Plan A. What phones can I get?"
    activate A
    A->>P: search_devices(plan_id="Plan A", model="Pixel 9")
    P-->>A: [Pixel 9 Pro, Pixel 9]
    A-->>U: "With Plan A, you can get the Pixel 9 or Pixel 9 Pro."
    deactivate A

    U->>A: "Can I get a better price on Plan A?"
    activate A
    A->>D: request_manager_discount(plan="Plan A", employee="E123")
    D-->>A: {status: "APPROVED", discount: "15%", new_price: "$45"}
    A-->>U: "Great news! I applied a 15% manager discount. Total is now $45."
    deactivate A

    U->>A: "Perfect, order it."
    activate A
    A->>P: create_order(plan="Plan A", device="Pixel 9", discount="15%")
    P-->>A: {order_id: "ORD-999", ship_date: "2023-10-25"}
    A-->>U: "Done! Order #ORD-999 arrives on Oct 25."
    deactivate A
```

---

## 3. Evaluation Plan
> **Goal**: Verify E2E correctness and discount logic.

### 3.1 Design-Time Verification
*   **Diagram Check**: Mermaid diagrams render without syntax errors.
*   **Tool Check**: All tools have defined inputs/outputs in the schema.

### 3.2 Test Scenarios (Manual / Replay)

#### **Scenario 1: The Happy Path**
*   **Input**: "I want the basic plan and an iPhone 15." -> "Go ahead."
*   **Success Criteria**:
    *   Agent finds "Basic Plan" and "iPhone 15".
    *   Agent calls `create_order` with correct IDs.
    *   Output contains Order ID and Date.

#### **Scenario 2: The Deal Hunter (Negotiation)**
*   **Input**: "This seems expensive. Any extra discounts?"
*   **Success Criteria**:
    *   Agent calls `request_manager_discount`.
    *   **If Approved**: seamlessly updates the quote and communicates the new price.
    *   **If Denied**: politely explains limits and offers lower-tier alternatives.


#### **Scenario 3: Out of Stock / Unhappy Path**
*   **Input**: "I want a Gold iPhone 4." (Obsolete/Unavailable)
*   **Success Criteria**:
    *   `search_devices` returns empty.
    *   Agent handles empty state gracefully: "I couldn't find an iPhone 4, but the iPhone SE is similar and available."

#### **Scenario 4: Plan Only (BYOD)**
*   **Input**: "I have an iPhone 14 already. Just need a plan with international calling."
*   **Success Criteria**:
    *   Agent skips device search.
    *   `search_plans` filter includes `intl_calling=True`.
    *   Cart contains only a plan item.

#### **Scenario 5: Ambiguous Requirements (Refinement)**
*   **Input**: "I need a phone for business travel."
*   **Success Criteria**:
    *   Agent asks clarifying questions: "Do you need international calling?" "Do you have a preferred device brand?"
    *   Does NOT hallucinate a recommendation without gathering requirements.

#### **Scenario 6: Change of Mind (Mid-Flow)**
*   **Input**: (After selecting Pixel 9) "Actually, I prefer the Galaxy S24."
*   **Success Criteria**:
    *   Agent updates `cart` (removes Pixel 9, adds Galaxy S24).
    *   Recalculates total price.
    *   Confirms the switch before proceeding.

#### **Scenario 7: Provider API Failure**
*   **Input**: "Show me plans." (Simulated `search_plans` timeout/error)
*   **Success Criteria**:
    *   Agent apologizes: "I'm having trouble connecting to the provider right now."
    *   Offers to functionality that doesn't require live data (e.g., specific general EPP info) or asks user to try again later.
    *   Does NOT crash or show raw stack traces.
